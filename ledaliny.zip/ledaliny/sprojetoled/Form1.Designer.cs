﻿namespace sprojetoled
{
    partial class LED
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkstatus = new System.Windows.Forms.CheckBox();
            this.btn9 = new System.Windows.Forms.Button();
            this.txtLed = new System.Windows.Forms.TextBox();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.checkled8 = new System.Windows.Forms.CheckBox();
            this.checkled7 = new System.Windows.Forms.CheckBox();
            this.checkled6 = new System.Windows.Forms.CheckBox();
            this.checkled5 = new System.Windows.Forms.CheckBox();
            this.checkled4 = new System.Windows.Forms.CheckBox();
            this.checkled3 = new System.Windows.Forms.CheckBox();
            this.checkled2 = new System.Windows.Forms.CheckBox();
            this.checkled1 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // checkstatus
            // 
            this.checkstatus.AutoSize = true;
            this.checkstatus.Location = new System.Drawing.Point(158, 293);
            this.checkstatus.Name = "checkstatus";
            this.checkstatus.Size = new System.Drawing.Size(56, 17);
            this.checkstatus.TabIndex = 38;
            this.checkstatus.Text = "Status";
            this.checkstatus.UseVisualStyleBackColor = true;
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(66, 327);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(75, 23);
            this.btn9.TabIndex = 37;
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // txtLed
            // 
            this.txtLed.Location = new System.Drawing.Point(66, 260);
            this.txtLed.Multiline = true;
            this.txtLed.Name = "txtLed";
            this.txtLed.Size = new System.Drawing.Size(70, 50);
            this.txtLed.TabIndex = 36;
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(39, 68);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(75, 23);
            this.btn8.TabIndex = 35;
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(125, 68);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(75, 23);
            this.btn7.TabIndex = 34;
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(211, 68);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 23);
            this.btn6.TabIndex = 33;
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(297, 68);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(75, 23);
            this.btn5.TabIndex = 32;
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(383, 68);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 23);
            this.btn4.TabIndex = 31;
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(469, 68);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(75, 23);
            this.btn3.TabIndex = 30;
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(555, 68);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 23);
            this.btn2.TabIndex = 29;
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(641, 68);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 28;
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // checkled8
            // 
            this.checkled8.AutoSize = true;
            this.checkled8.Location = new System.Drawing.Point(39, 36);
            this.checkled8.Name = "checkled8";
            this.checkled8.Size = new System.Drawing.Size(65, 17);
            this.checkled8.TabIndex = 27;
            this.checkled8.Text = "Led - 08";
            this.checkled8.UseVisualStyleBackColor = true;
            // 
            // checkled7
            // 
            this.checkled7.AutoSize = true;
            this.checkled7.Location = new System.Drawing.Point(125, 36);
            this.checkled7.Name = "checkled7";
            this.checkled7.Size = new System.Drawing.Size(65, 17);
            this.checkled7.TabIndex = 26;
            this.checkled7.Text = "Led - 07";
            this.checkled7.UseVisualStyleBackColor = true;
            // 
            // checkled6
            // 
            this.checkled6.AutoSize = true;
            this.checkled6.Location = new System.Drawing.Point(211, 36);
            this.checkled6.Name = "checkled6";
            this.checkled6.Size = new System.Drawing.Size(65, 17);
            this.checkled6.TabIndex = 25;
            this.checkled6.Text = "Led - 06";
            this.checkled6.UseVisualStyleBackColor = true;
            // 
            // checkled5
            // 
            this.checkled5.AutoSize = true;
            this.checkled5.Location = new System.Drawing.Point(297, 36);
            this.checkled5.Name = "checkled5";
            this.checkled5.Size = new System.Drawing.Size(65, 17);
            this.checkled5.TabIndex = 24;
            this.checkled5.Text = "Led - 05";
            this.checkled5.UseVisualStyleBackColor = true;
            // 
            // checkled4
            // 
            this.checkled4.AutoSize = true;
            this.checkled4.Location = new System.Drawing.Point(383, 36);
            this.checkled4.Name = "checkled4";
            this.checkled4.Size = new System.Drawing.Size(65, 17);
            this.checkled4.TabIndex = 23;
            this.checkled4.Text = "Led - 04";
            this.checkled4.UseVisualStyleBackColor = true;
            // 
            // checkled3
            // 
            this.checkled3.AutoSize = true;
            this.checkled3.Location = new System.Drawing.Point(469, 36);
            this.checkled3.Name = "checkled3";
            this.checkled3.Size = new System.Drawing.Size(65, 17);
            this.checkled3.TabIndex = 22;
            this.checkled3.Text = "Led - 03";
            this.checkled3.UseVisualStyleBackColor = true;
            // 
            // checkled2
            // 
            this.checkled2.AutoSize = true;
            this.checkled2.Location = new System.Drawing.Point(555, 36);
            this.checkled2.Name = "checkled2";
            this.checkled2.Size = new System.Drawing.Size(65, 17);
            this.checkled2.TabIndex = 21;
            this.checkled2.Text = "Led - 02";
            this.checkled2.UseVisualStyleBackColor = true;
            // 
            // checkled1
            // 
            this.checkled1.AutoSize = true;
            this.checkled1.Location = new System.Drawing.Point(641, 36);
            this.checkled1.Name = "checkled1";
            this.checkled1.Size = new System.Drawing.Size(65, 17);
            this.checkled1.TabIndex = 20;
            this.checkled1.Text = "Led - 01";
            this.checkled1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.checkstatus);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.txtLed);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.checkled8);
            this.Controls.Add(this.checkled7);
            this.Controls.Add(this.checkled6);
            this.Controls.Add(this.checkled5);
            this.Controls.Add(this.checkled4);
            this.Controls.Add(this.checkled3);
            this.Controls.Add(this.checkled2);
            this.Controls.Add(this.checkled1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkstatus;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.TextBox txtLed;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.CheckBox checkled8;
        private System.Windows.Forms.CheckBox checkled7;
        private System.Windows.Forms.CheckBox checkled6;
        private System.Windows.Forms.CheckBox checkled5;
        private System.Windows.Forms.CheckBox checkled4;
        private System.Windows.Forms.CheckBox checkled3;
        private System.Windows.Forms.CheckBox checkled2;
        private System.Windows.Forms.CheckBox checkled1;
    }
}

